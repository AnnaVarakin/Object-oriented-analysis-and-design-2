﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Linq;

namespace CoffeeShopNoBuilder
{
    // ========== ПЕРЕЧИСЛЕНИЯ ==========
    public enum MilkType { Нет, Коровье, Банановое, Овсяное, Миндальное, Кокосовое, Соевое }
    public enum SyrupType { Нет, Карамель, Ваниль, Фундук, Шоколад, Кокос, Лаванда, Мятный }
    public enum TemperatureType { Горячий, Теплый, Холодный, Со_Льдом }
    public enum AdditiveType { ВзбитыеСливки, Мороженое, Маршмеллоу }
    public enum ToppingType { Нет, Шоколадный, Карамельный, Ягодный }
    public enum DecorType { Нет, Корица, Какао_Порошок }
    public enum PackagingType { ВЗаведении, ССобой, СвояКружка }
    public enum CoffeeBaseType { Эспрессо, Капучино, Латте, Раф }

    // ========== БАЗОВЫЙ АБСТРАКТНЫЙ КЛАСС ==========
    public abstract class CoffeeDrink
    {
        public CoffeeBaseType Base { get; protected set; }
        public MilkType Milk { get; set; } = MilkType.Нет;
        public SyrupType Syrup { get; set; } = SyrupType.Нет;
        public int SyrupDose { get; set; } = 1;
        public TemperatureType Temperature { get; set; } = TemperatureType.Горячий;
        public List<AdditiveType> Additives { get; } = new List<AdditiveType>();
        public ToppingType Topping { get; set; } = ToppingType.Нет;
        public DecorType Decor { get; set; } = DecorType.Нет;
        public int Volume { get; set; } = 300;
        public PackagingType Packaging { get; set; } = PackagingType.ВЗаведении;

        public virtual string GetDescription()
        {
            var parts = new List<string> { $"{Base} {Volume}мл, {Temperature}" };
            if (Milk != MilkType.Нет) parts.Add($"молоко: {Milk}");
            if (Syrup != SyrupType.Нет) parts.Add($"сироп: {Syrup} ({SyrupDose} дозы)");
            if (Additives.Any()) parts.Add($"добавки: {string.Join(", ", Additives)}");
            if (Topping != ToppingType.Нет) parts.Add($"топпинг: {Topping}");
            if (Decor != DecorType.Нет) parts.Add($"декор: {Decor}");
            parts.Add($"упаковка: {(Packaging == PackagingType.ВЗаведении ? "в заведении" : Packaging == PackagingType.ССобой ? "с собой" : "своя кружка")}");
            return string.Join(", ", parts);
        }

        protected void ValidateMilkRequired()
        {
            if (Milk == MilkType.Нет)
                throw new Exception($"{Base} обязательно должен быть с молоком!");
        }
    }

    // ========== КОНКРЕТНЫЕ КЛАССЫ НАПИТКОВ ==========
    public class Espresso : CoffeeDrink
    {
        public Espresso()
        {
            Base = CoffeeBaseType.Эспрессо;
            Volume = 60;
        }

        public void SetMilk(MilkType milk)
        {
            if (milk != MilkType.Нет)
                throw new Exception("Эспрессо не подают с молоком!");
            Milk = milk;
        }
    }

    public class Cappuccino : CoffeeDrink
    {
        public Cappuccino()
        {
            Base = CoffeeBaseType.Капучино;
            Volume = 300;
        }

        public void SetMilk(MilkType milk)
        {
            Milk = milk;
            ValidateMilkRequired();
        }
    }

    public class Latte : CoffeeDrink
    {
        public Latte()
        {
            Base = CoffeeBaseType.Латте;
            Volume = 350;
        }

        public void SetMilk(MilkType milk)
        {
            Milk = milk;
            ValidateMilkRequired();
        }

        public void SetLatteArt(bool art)
        {
            if (art) Decor = DecorType.Какао_Порошок;
        }
    }

    public class Raf : CoffeeDrink
    {
        public Raf()
        {
            Base = CoffeeBaseType.Раф;
            Volume = 300;
        }

        public void SetMilk(MilkType milk)
        {
            Milk = milk;
            ValidateMilkRequired();
        }
    }

    // ========== ГЛАВНАЯ ФОРМА ==========
    public class CoffeeShopGUI : Form
    {
        private ComboBox cmbBase;
        private ComboBox cmbMilk;
        private ComboBox cmbSyrup;
        private ComboBox cmbTemperature;
        private ComboBox cmbTopping;
        private ComboBox cmbDecor;
        private ComboBox cmbVolume;
        private ComboBox cmbPackaging;
        private NumericUpDown nudSyrupDose;
        private CheckedListBox clbAdditives;
        private Button btnBuildCoffee;
        private Button btnReset;
        private TextBox txtResult;

        private readonly string[] _allMilkOptions = { "Нет", "Коровье", "Банановое", "Овсяное", "Миндальное", "Кокосовое", "Соевое" };
        private readonly string[] _milkWithoutNo = { "Коровье", "Банановое", "Овсяное", "Миндальное", "Кокосовое", "Соевое" };

        public CoffeeShopGUI()
        {
            InitializeComponent();
            LoadComboBoxes();
        }

        private void InitializeComponent()
        {
            this.Text = "Кофе-шоп (без паттерна)";
            this.Size = new Size(700, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);
            this.BackColor = Color.FromArgb(230, 209, 186);

            int y = 20;

            // Основа
            Controls.Add(new Label { Text = "Основа:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbBase = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbBase.Items.AddRange(new[] { "Эспрессо", "Капучино", "Латте", "Раф" });
            cmbBase.SelectedIndex = 1;
            Controls.Add(cmbBase);
            y += 35;

            // Молоко
            Controls.Add(new Label { Text = "Молоко:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbMilk = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbMilk.Items.AddRange(_allMilkOptions);
            cmbMilk.SelectedIndex = 1;
            Controls.Add(cmbMilk);
            y += 35;

            // Сироп
            Controls.Add(new Label { Text = "Сироп:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbSyrup = new ComboBox { Location = new Point(140, y), Size = new Size(150, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSyrup.Items.AddRange(new[] { "Нет", "Карамель", "Ваниль", "Фундук", "Шоколад", "Кокос", "Лаванда", "Мятный" });
            cmbSyrup.SelectedIndex = 0;
            Controls.Add(cmbSyrup);

            nudSyrupDose = new NumericUpDown { Location = new Point(300, y), Size = new Size(40, 30), Minimum = 1, Maximum = 3, Value = 1 };
            Controls.Add(nudSyrupDose);
            y += 35;

            // Температура
            Controls.Add(new Label { Text = "Температура:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbTemperature = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbTemperature.Items.AddRange(new[] { "Горячий", "Теплый", "Холодный", "Со льдом" });
            cmbTemperature.SelectedIndex = 0;
            Controls.Add(cmbTemperature);
            y += 35;

            // Добавки
            Controls.Add(new Label { Text = "Добавки:", Location = new Point(20, y), Size = new Size(100, 25) });
            clbAdditives = new CheckedListBox { Location = new Point(140, y), Size = new Size(200, 80) };
            clbAdditives.Items.AddRange(new[] { "Взбитые сливки", "Мороженое", "Маршмеллоу" });
            Controls.Add(clbAdditives);
            y += 85;

            // Топпинг
            Controls.Add(new Label { Text = "Топпинг:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbTopping = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbTopping.Items.AddRange(new[] { "Нет", "Шоколадный", "Карамельный", "Ягодный" });
            cmbTopping.SelectedIndex = 0;
            Controls.Add(cmbTopping);
            y += 35;

            // Декор
            Controls.Add(new Label { Text = "Декор:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbDecor = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbDecor.Items.AddRange(new[] { "Нет", "Корица", "Какао-порошок" });
            cmbDecor.SelectedIndex = 0;
            Controls.Add(cmbDecor);
            y += 35;

            // Объем
            Controls.Add(new Label { Text = "Объем (мл):", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbVolume = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbVolume.Items.AddRange(new[] { "200 мл", "300 мл", "400 мл" });
            cmbVolume.SelectedIndex = 1;
            Controls.Add(cmbVolume);
            y += 35;

            // Упаковка
            Controls.Add(new Label { Text = "Упаковка:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbPackaging = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbPackaging.Items.AddRange(new[] { "В заведении", "С собой", "Своя кружка" });
            cmbPackaging.SelectedIndex = 0;
            Controls.Add(cmbPackaging);
            y += 35;

            // Кнопки
            btnBuildCoffee = new Button
            {
                Text = "ПРИГОТОВИТЬ",
                Location = new Point(20, y),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            btnReset = new Button
            {
                Text = "Сброс",
                Location = new Point(190, y),
                Size = new Size(100, 40),
                BackColor = Color.FromArgb(158, 158, 158),
                ForeColor = Color.White
            };
            Controls.AddRange(new[] { btnBuildCoffee, btnReset });
            y += 50;

            // Результат
            Controls.Add(new Label { Text = "Ваш заказ:", Location = new Point(20, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 11, FontStyle.Bold) });
            txtResult = new TextBox { Location = new Point(20, y + 30), Size = new Size(640, 100), Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = Color.White };
            Controls.Add(txtResult);

            // Подписка на события
            cmbBase.SelectedIndexChanged += OnBaseChanged;
            btnBuildCoffee.Click += OnBuildCoffee;
            btnReset.Click += OnReset;
        }

        private void LoadComboBoxes() => OnBaseChanged(null, null);

        private void OnBaseChanged(object sender, EventArgs e)
        {
            string selected = cmbBase.SelectedItem?.ToString();
            string currentMilk = cmbMilk.SelectedItem?.ToString() ?? "Коровье";

            cmbMilk.Items.Clear();
            cmbTemperature.Enabled = true;

            if (selected == "Эспрессо")
            {
                cmbMilk.Items.AddRange(_allMilkOptions);
                cmbMilk.SelectedItem = "Нет";
                cmbMilk.Enabled = false;
            }
            else
            {
                cmbMilk.Items.AddRange(_milkWithoutNo);
                cmbMilk.SelectedItem = _milkWithoutNo.Contains(currentMilk) ? currentMilk : _milkWithoutNo[0];
                cmbMilk.Enabled = true;
            }

            if (selected == "Раф")
            {
                cmbTemperature.SelectedItem = "Горячий";
                cmbTemperature.Enabled = false;
            }
        }

        private void OnBuildCoffee(object sender, EventArgs e)
        {
            try
            {
                // СОЗДАЕМ НУЖНЫЙ ТИП НАПИТКА В ЗАВИСИМОСТИ ОТ ОСНОВЫ
                CoffeeDrink drink = cmbBase.SelectedItem?.ToString() switch
                {
                    "Эспрессо" => new Espresso(),
                    "Капучино" => new Cappuccino(),
                    "Латте" => new Latte(),
                    "Раф" => new Raf(),
                    _ => new Cappuccino()
                };

                // ЗАПОЛНЯЕМ СВОЙСТВА (для каждого типа по-разному)
                switch (drink)
                {
                    case Espresso esp:
                        esp.SetMilk(ParseMilk(cmbMilk.SelectedItem?.ToString() ?? "Нет"));
                        break;
                    case Cappuccino cap:
                        cap.SetMilk(ParseMilk(cmbMilk.SelectedItem?.ToString() ?? "Коровье"));
                        break;
                    case Latte lat:
                        lat.SetMilk(ParseMilk(cmbMilk.SelectedItem?.ToString() ?? "Коровье"));
                        if (cmbDecor.SelectedItem?.ToString() == "Какао-порошок")
                            lat.SetLatteArt(true);
                        break;
                    case Raf raf:
                        raf.SetMilk(ParseMilk(cmbMilk.SelectedItem?.ToString() ?? "Коровье"));
                        break;
                }

                // ОБЩИЕ СВОЙСТВА
                if (cmbSyrup.SelectedItem?.ToString() != "Нет")
                {
                    drink.Syrup = ParseSyrup(cmbSyrup.SelectedItem?.ToString() ?? "Нет");
                    drink.SyrupDose = (int)nudSyrupDose.Value;
                }

                drink.Temperature = ParseTemperature(cmbTemperature.SelectedItem?.ToString() ?? "Горячий");

                foreach (var item in clbAdditives.CheckedItems)
                    drink.Additives.Add(ParseAdditive(item.ToString()));

                if (cmbTopping.SelectedItem?.ToString() != "Нет")
                    drink.Topping = ParseTopping(cmbTopping.SelectedItem?.ToString() ?? "Нет");

                // Декор (если это не Latte, где он уже мог быть установлен)
                if (cmbDecor.SelectedItem?.ToString() != "Нет" && drink is not Latte)
                    drink.Decor = ParseDecor(cmbDecor.SelectedItem?.ToString() ?? "Нет");

                string vol = cmbVolume.SelectedItem?.ToString()?.Replace(" мл", "") ?? "300";
                drink.Volume = int.Parse(vol);
                drink.Packaging = ParsePackaging(cmbPackaging.SelectedItem?.ToString() ?? "В заведении");

                txtResult.Text = drink.GetDescription();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void OnReset(object sender, EventArgs e)
        {
            cmbBase.SelectedIndex = 1;
            OnBaseChanged(null, null);
            cmbSyrup.SelectedIndex = 0;
            nudSyrupDose.Value = 1;
            cmbTemperature.SelectedIndex = 0;
            for (int i = 0; i < clbAdditives.Items.Count; i++)
                clbAdditives.SetItemChecked(i, false);
            cmbTopping.SelectedIndex = 0;
            cmbDecor.SelectedIndex = 0;
            cmbVolume.SelectedIndex = 1;
            cmbPackaging.SelectedIndex = 0;
            txtResult.Clear();
        }

        // Парсинг - переименовал параметры с 'v' на 'val'
        private MilkType ParseMilk(string val) => val switch
        {
            "Коровье" => MilkType.Коровье,
            "Банановое" => MilkType.Банановое,
            "Овсяное" => MilkType.Овсяное,
            "Миндальное" => MilkType.Миндальное,
            "Кокосовое" => MilkType.Кокосовое,
            "Соевое" => MilkType.Соевое,
            _ => MilkType.Нет
        };

        private SyrupType ParseSyrup(string val) => val switch
        {
            "Карамель" => SyrupType.Карамель,
            "Ваниль" => SyrupType.Ваниль,
            "Фундук" => SyrupType.Фундук,
            "Шоколад" => SyrupType.Шоколад,
            "Кокос" => SyrupType.Кокос,
            "Лаванда" => SyrupType.Лаванда,
            "Мятный" => SyrupType.Мятный,
            _ => SyrupType.Нет
        };

        private TemperatureType ParseTemperature(string val) => val switch
        {
            "Горячий" => TemperatureType.Горячий,
            "Теплый" => TemperatureType.Теплый,
            "Холодный" => TemperatureType.Холодный,
            "Со льдом" => TemperatureType.Со_Льдом,
            _ => TemperatureType.Горячий
        };

        private AdditiveType ParseAdditive(string val) => val switch
        {
            "Взбитые сливки" => AdditiveType.ВзбитыеСливки,
            "Мороженое" => AdditiveType.Мороженое,
            "Маршмеллоу" => AdditiveType.Маршмеллоу,
            _ => AdditiveType.ВзбитыеСливки
        };

        private ToppingType ParseTopping(string val) => val switch
        {
            "Шоколадный" => ToppingType.Шоколадный,
            "Карамельный" => ToppingType.Карамельный,
            "Ягодный" => ToppingType.Ягодный,
            _ => ToppingType.Нет
        };

        private DecorType ParseDecor(string val) => val switch
        {
            "Корица" => DecorType.Корица,
            "Какао-порошок" => DecorType.Какао_Порошок,
            _ => DecorType.Нет
        };

        private PackagingType ParsePackaging(string val) => val switch
        {
            "В заведении" => PackagingType.ВЗаведении,
            "С собой" => PackagingType.ССобой,
            "Своя кружка" => PackagingType.СвояКружка,
            _ => PackagingType.ВЗаведении
        };
    }

    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CoffeeShopGUI());
        }
    }
}