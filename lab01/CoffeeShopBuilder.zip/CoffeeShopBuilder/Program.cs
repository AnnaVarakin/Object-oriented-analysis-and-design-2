﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;
using System.Linq;

namespace CoffeeShopBuilder
{
    public enum MilkType { Нет, Коровье, Банановое, Овсяное, Миндальное, Кокосовое, Соевое }
    public enum SyrupType { Нет, Карамель, Ваниль, Фундук, Шоколад, Кокос, Лаванда, Мятный }
    public enum TemperatureType { Горячий, Теплый, Холодный, Со_Льдом }
    public enum AdditiveType { ВзбитыеСливки, Мороженое, Маршмеллоу }
    public enum ToppingType { Нет, Шоколадный, Карамельный, Ягодный }
    public enum DecorType { Нет, Корица, Какао_Порошок }
    public enum PackagingType { ВЗаведении, ССобой, СвояКружка }
    public enum CoffeeBaseType { Эспрессо, Капучино, Латте, Раф }

    public class CoffeeDrink
    {
        private CoffeeBaseType Base { get; set; }
        private MilkType Milk { get; set; } = MilkType.Нет;
        private SyrupType Syrup { get; set; } = SyrupType.Нет;
        private int SyrupDose { get; set; } = 1;
        private TemperatureType Temperature { get; set; } = TemperatureType.Горячий;
        private List<AdditiveType> Additives { get; } = new List<AdditiveType>();
        private ToppingType Topping { get; set; } = ToppingType.Нет;
        private DecorType Decor { get; set; } = DecorType.Нет;
        private int Volume { get; set; } = 300;
        private PackagingType Packaging { get; set; } = PackagingType.ВЗаведении;

        public string GetDescription()
        {
            var parts = new List<string> { $"{Base} {Volume}мл, {Temperature}" };
            if (Milk != MilkType.Нет) parts.Add($"молоко: {Milk}");
            if (Syrup != SyrupType.Нет) parts.Add($"сироп: {Syrup} ({SyrupDose} дозы)");
            if (Additives.Any()) parts.Add($"добавки: {string.Join(", ", Additives)}");
            if (Topping != ToppingType.Нет) parts.Add($"топпинг: {Topping}");
            if (Decor != DecorType.Нет) parts.Add($"декор: {Decor}");
            parts.Add($"упаковка: {(Packaging == PackagingType.ВЗаведении ? "в заведении" : Packaging == PackagingType.ССобой ? "с собой" : "своя кружка")}");
            return string.Join(", ", parts);
        }
    }

    // АБСТРАКТНЫЙ СТРОИТЕЛЬ 
    public abstract class CoffeeDrinkBuilder
    {
        protected CoffeeDrink coffee = new CoffeeDrink();
        public void Reset() => coffee = new CoffeeDrink();
        public CoffeeDrink GetResult() => coffee;

        public abstract CoffeeDrinkBuilder SetBase();
        public abstract CoffeeDrinkBuilder SetDefaultVolume();

        public virtual CoffeeDrinkBuilder SetMilk(MilkType milk) { coffee.Milk = milk; return this; }
        public virtual CoffeeDrinkBuilder SetSyrup(SyrupType syrup, int dose = 1) { coffee.Syrup = syrup; coffee.SyrupDose = dose; return this; }
        public virtual CoffeeDrinkBuilder SetTemperature(TemperatureType temp) { coffee.Temperature = temp; return this; }
        public virtual CoffeeDrinkBuilder AddAdditive(AdditiveType add) { coffee.Additives.Add(add); return this; }
        public virtual CoffeeDrinkBuilder SetTopping(ToppingType top) { coffee.Topping = top; return this; }
        public virtual CoffeeDrinkBuilder SetDecor(DecorType dec) { coffee.Decor = dec; return this; }
        public virtual CoffeeDrinkBuilder SetVolume(int vol) { coffee.Volume = vol; return this; }
        public virtual CoffeeDrinkBuilder SetPackaging(PackagingType pack) { coffee.Packaging = pack; return this; }

        protected bool ValidateMilkRequired() => coffee.Milk != MilkType.Нет ? true :
            throw new Exception($"{coffee.Base} обязательно должен быть с молоком!");
    }

    // СТРОИТЕЛИ 
    public class EspressoBuilder : CoffeeDrinkBuilder
    {
        public EspressoBuilder() => Reset();
        public override CoffeeDrinkBuilder SetBase() { coffee.Base = CoffeeBaseType.Эспрессо; return this; }
        public override CoffeeDrinkBuilder SetDefaultVolume() { coffee.Volume = 60; return this; }
        public override CoffeeDrinkBuilder SetMilk(MilkType milk) => milk == MilkType.Нет ? base.SetMilk(milk) :
            throw new Exception("Эспрессо не подают с молоком!");
    }

    public class CappuccinoBuilder : CoffeeDrinkBuilder
    {
        public CappuccinoBuilder() => Reset();
        public override CoffeeDrinkBuilder SetBase() { coffee.Base = CoffeeBaseType.Капучино; return this; }
        public override CoffeeDrinkBuilder SetDefaultVolume() { coffee.Volume = 300; return this; }
        public override CoffeeDrinkBuilder SetMilk(MilkType milk) { base.SetMilk(milk); ValidateMilkRequired(); return this; }
    }

    public class LatteBuilder : CoffeeDrinkBuilder
    {
        public LatteBuilder() => Reset();
        public override CoffeeDrinkBuilder SetBase() { coffee.Base = CoffeeBaseType.Латте; return this; }
        public override CoffeeDrinkBuilder SetDefaultVolume() { coffee.Volume = 350; return this; }
        public override CoffeeDrinkBuilder SetMilk(MilkType milk) { base.SetMilk(milk); ValidateMilkRequired(); return this; }
        public LatteBuilder SetLatteArt(bool art) { if (art) coffee.Decor = DecorType.Какао_Порошок; return this; }
    }

    public class RafCoffeeBuilder : CoffeeDrinkBuilder
    {
        public RafCoffeeBuilder() => Reset();
        public override CoffeeDrinkBuilder SetBase() { coffee.Base = CoffeeBaseType.Раф; return this; }
        public override CoffeeDrinkBuilder SetDefaultVolume() { coffee.Volume = 300; return this; }
        public override CoffeeDrinkBuilder SetMilk(MilkType milk) { base.SetMilk(milk); ValidateMilkRequired(); return this; }
    }

    // ФОРМА 
    public class CoffeeShopGUI : Form
    {
        private ComboBox cmbBase, cmbMilk, cmbSyrup, cmbTemperature, cmbTopping, cmbDecor, cmbVolume, cmbPackaging;
        private NumericUpDown nudSyrupDose;
        private CheckedListBox clbAdditives;
        private Button btnBuildCoffee, btnReset;
        private TextBox txtResult;

        private readonly string[] _allMilkOptions = { "Нет", "Коровье", "Банановое", "Овсяное", "Миндальное", "Кокосовое", "Соевое" };
        private readonly string[] _milkWithoutNo = { "Коровье", "Банановое", "Овсяное", "Миндальное", "Кокосовое", "Соевое" };

        public CoffeeShopGUI()
        {
            InitializeComponent();
            LoadComboBoxes();
        }

        private void InitializeComponent()
        {
            this.Text = "Кофе-билдер";
            this.Size = new Size(700, 650);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);
            this.BackColor = Color.FromArgb(230, 209, 186);

            int y = 20;
            void AddLabel(string text, ref ComboBox cb, string[] items, int selected = 1, bool enabled = true)
            {
                Controls.Add(new Label { Text = text, Location = new Point(20, y), Size = new Size(100, 25) });
                cb = new ComboBox { Location = new Point(140, y), Size = new Size(200, 30), DropDownStyle = ComboBoxStyle.DropDownList, Enabled = enabled };
                cb.Items.AddRange(items);
                cb.SelectedIndex = selected;
                Controls.Add(cb);
                y += 35;
            }

            AddLabel("Основа:", ref cmbBase, new[] { "Эспрессо", "Капучино", "Латте", "Раф" }, 1);
            AddLabel("Молоко:", ref cmbMilk, _allMilkOptions, 1);

            Controls.Add(new Label { Text = "Сироп:", Location = new Point(20, y), Size = new Size(100, 25) });
            cmbSyrup = new ComboBox { Location = new Point(140, y), Size = new Size(150, 30), DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSyrup.Items.AddRange(new[] { "Нет", "Карамель", "Ваниль", "Фундук", "Шоколад", "Кокос", "Лаванда", "Мятный" });
            cmbSyrup.SelectedIndex = 0;
            Controls.Add(cmbSyrup);

            nudSyrupDose = new NumericUpDown { Location = new Point(300, y), Size = new Size(40, 30), Minimum = 1, Maximum = 3, Value = 1 };
            Controls.Add(nudSyrupDose);
            y += 35;

            AddLabel("Температура:", ref cmbTemperature, new[] { "Горячий", "Теплый", "Холодный", "Со льдом" }, 0);

            Controls.Add(new Label { Text = "Добавки:", Location = new Point(20, y), Size = new Size(100, 25) });
            clbAdditives = new CheckedListBox { Location = new Point(140, y), Size = new Size(200, 80) };
            clbAdditives.Items.AddRange(new[] { "Взбитые сливки", "Мороженое", "Маршмеллоу" });
            Controls.Add(clbAdditives);
            y += 85;

            AddLabel("Топпинг:", ref cmbTopping, new[] { "Нет", "Шоколадный", "Карамельный", "Ягодный" }, 0);
            AddLabel("Декор:", ref cmbDecor, new[] { "Нет", "Корица", "Какао-порошок" }, 0);
            AddLabel("Объем (мл):", ref cmbVolume, new[] { "200 мл", "300 мл", "400 мл" }, 1);
            AddLabel("Упаковка:", ref cmbPackaging, new[] { "В заведении", "С собой", "Своя кружка" }, 0);

            btnBuildCoffee = new Button
            {
                Text = "ПРИГОТОВИТЬ",
                Location = new Point(20, y),
                Size = new Size(150, 40),
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            btnReset = new Button
            {
                Text = "Сброс",
                Location = new Point(190, y),
                Size = new Size(100, 40),
                BackColor = Color.FromArgb(158, 158, 158),
                ForeColor = Color.White
            };
            Controls.AddRange(new[] { btnBuildCoffee, btnReset });
            y += 50;

            Controls.Add(new Label { Text = "Ваш заказ:", Location = new Point(20, y), Size = new Size(200, 25), Font = new Font("Segoe UI", 11, FontStyle.Bold) });
            txtResult = new TextBox { Location = new Point(20, y + 30), Size = new Size(640, 100), Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = Color.White };
            Controls.Add(txtResult);

            cmbBase.SelectedIndexChanged += OnBaseChanged;
            btnBuildCoffee.Click += OnBuildCoffee;
            btnReset.Click += OnReset;
        }

        private void LoadComboBoxes() => OnBaseChanged(null, null);

        private void OnBaseChanged(object sender, EventArgs e)
        {
            string selected = cmbBase.SelectedItem?.ToString();
            string currentMilk = cmbMilk.SelectedItem?.ToString() ?? "Коровье";

            cmbMilk.Items.Clear();
            cmbTemperature.Enabled = true;

            if (selected == "Эспрессо")
            {
                cmbMilk.Items.AddRange(_allMilkOptions);
                cmbMilk.SelectedItem = "Нет";
                cmbMilk.Enabled = false;
            }
            else
            {
                cmbMilk.Items.AddRange(_milkWithoutNo);
                cmbMilk.SelectedItem = _milkWithoutNo.Contains(currentMilk) ? currentMilk : _milkWithoutNo[0];
                cmbMilk.Enabled = true;
            }

            if (selected == "Раф")
            {
                cmbTemperature.SelectedItem = "Горячий";
                cmbTemperature.Enabled = false;
            }
        }

        private void OnBuildCoffee(object sender, EventArgs e)
        {
            try
            {
                CoffeeDrinkBuilder builder = cmbBase.SelectedItem?.ToString() switch
                {
                    "Эспрессо" => new EspressoBuilder(),
                    "Капучино" => new CappuccinoBuilder(),
                    "Латте" => new LatteBuilder(),
                    "Раф" => new RafCoffeeBuilder(),
                    _ => new CappuccinoBuilder()
                };

                if (cmbMilk.SelectedItem?.ToString() != "Нет")
                    builder.SetMilk(ParseMilk(cmbMilk.SelectedItem?.ToString() ?? "Нет"));

                if (cmbSyrup.SelectedItem?.ToString() != "Нет")
                    builder.SetSyrup(ParseSyrup(cmbSyrup.SelectedItem?.ToString() ?? "Нет"), (int)nudSyrupDose.Value);

                builder.SetTemperature(ParseTemperature(cmbTemperature.SelectedItem?.ToString() ?? "Горячий"));

                foreach (var item in clbAdditives.CheckedItems)
                    builder.AddAdditive(ParseAdditive(item.ToString()));

                if (cmbTopping.SelectedItem?.ToString() != "Нет")
                    builder.SetTopping(ParseTopping(cmbTopping.SelectedItem?.ToString() ?? "Нет"));

                if (cmbDecor.SelectedItem?.ToString() != "Нет")
                    builder.SetDecor(ParseDecor(cmbDecor.SelectedItem?.ToString() ?? "Нет"));

                string vol = cmbVolume.SelectedItem?.ToString()?.Replace(" мл", "") ?? "300";
                builder.SetVolume(int.Parse(vol));
                builder.SetPackaging(ParsePackaging(cmbPackaging.SelectedItem?.ToString() ?? "В заведении"));

                txtResult.Text = builder.GetResult().GetDescription();
            }
            catch (Exception ex) { MessageBox.Show($"Ошибка: {ex.Message}"); }
        }

        private void OnReset(object sender, EventArgs e)
        {
            cmbBase.SelectedIndex = 1;
            OnBaseChanged(null, null);
            cmbSyrup.SelectedIndex = 0;
            nudSyrupDose.Value = 1;
            cmbTemperature.SelectedIndex = 0;
            for (int i = 0; i < clbAdditives.Items.Count; i++) clbAdditives.SetItemChecked(i, false);
            cmbTopping.SelectedIndex = 0;
            cmbDecor.SelectedIndex = 0;
            cmbVolume.SelectedIndex = 1;
            cmbPackaging.SelectedIndex = 0;
            txtResult.Clear();
        }
        private MilkType ParseMilk(string v) => v switch { "Коровье" => MilkType.Коровье, "Банановое" => MilkType.Банановое, "Овсяное" => MilkType.Овсяное, "Миндальное" => MilkType.Миндальное, "Кокосовое" => MilkType.Кокосовое, "Соевое" => MilkType.Соевое, _ => MilkType.Нет };
        private SyrupType ParseSyrup(string v) => v switch { "Карамель" => SyrupType.Карамель, "Ваниль" => SyrupType.Ваниль, "Фундук" => SyrupType.Фундук, "Шоколад" => SyrupType.Шоколад, "Кокос" => SyrupType.Кокос, "Лаванда" => SyrupType.Лаванда, "Мятный" => SyrupType.Мятный, _ => SyrupType.Нет };
        private TemperatureType ParseTemperature(string v) => v switch { "Горячий" => TemperatureType.Горячий, "Теплый" => TemperatureType.Теплый, "Холодный" => TemperatureType.Холодный, "Со льдом" => TemperatureType.Со_Льдом, _ => TemperatureType.Горячий };
        private AdditiveType ParseAdditive(string v) => v switch { "Взбитые сливки" => AdditiveType.ВзбитыеСливки, "Мороженое" => AdditiveType.Мороженое, "Маршмеллоу" => AdditiveType.Маршмеллоу, _ => AdditiveType.ВзбитыеСливки };
        private ToppingType ParseTopping(string v) => v switch { "Шоколадный" => ToppingType.Шоколадный, "Карамельный" => ToppingType.Карамельный, "Ягодный" => ToppingType.Ягодный, _ => ToppingType.Нет };
        private DecorType ParseDecor(string v) => v switch { "Корица" => DecorType.Корица, "Какао-порошок" => DecorType.Какао_Порошок, _ => DecorType.Нет };
        private PackagingType ParsePackaging(string v) => v switch { "В заведении" => PackagingType.ВЗаведении, "С собой" => PackagingType.ССобой, "Своя кружка" => PackagingType.СвояКружка, _ => PackagingType.ВЗаведении };
    }

    static class Program { [STAThread] static void Main() { Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new CoffeeShopGUI()); } }
}