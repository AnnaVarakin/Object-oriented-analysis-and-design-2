#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <random>
#include <chrono>
#include <thread>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include "httplib.h"

using namespace std;

// ВНУТРЕННЕЕ СОСТОЯНИЕ (ПРИСПОСОБЛЕНЕЦ)
class StarSet {
private:
    string m_color;      // "white", "yellow"
    int m_size;          // 1, 2, 3
    bool m_tracing;      // true = есть контур (полая)
    bool m_flicker;      // true = может мерцать

public:
    StarSet(const string& color, int size, bool tracing, bool flicker)
        : m_color(color), m_size(size), m_tracing(tracing), m_flicker(flicker) {}

    string getColor() const { return m_color; }
    int getSize() const { return m_size; }
    bool getTracing() const { return m_tracing; }
    bool getFlicker() const { return m_flicker; }
};

// ФАБРИКА ПРИСПОСОБЛЕНЦЕВ 
class StarFactory {
private:
    unordered_map<string, StarSet*> m_pool;
    mutex m_mutex;

    string makeKey(const string& color, int size, bool tracing, bool flicker) const {
        return color + "_" + to_string(size) + "_" + to_string(tracing) + "_" + to_string(flicker);
    }

public:
    ~StarFactory() {
        for (auto& pair : m_pool) {
            delete pair.second;
        }
    }

    StarSet* getStarSet(const string& color, int size, bool tracing, bool flicker) {
        string key = makeKey(color, size, tracing, flicker);
        lock_guard<mutex> lock(m_mutex);
        auto it = m_pool.find(key);
        if (it != m_pool.end()) {
            return it->second;
        }
        StarSet* newSet = new StarSet(color, size, tracing, flicker);
        m_pool[key] = newSet;
        return newSet;
    }
};

// КОНТЕКСТ (ВНЕШНЕЕ СОСТОЯНИЕ) 
class Star {
private:
    int m_id;
    int m_x;
    int m_y;
    StarSet* m_set;
    static StarFactory s_factory;

public:
    Star(int id, int x, int y, const string& color, int size, bool tracing, bool flicker)
        : m_id(id), m_x(x), m_y(y) {
        m_set = s_factory.getStarSet(color, size, tracing, flicker);
    }

    int getId() const { return m_id; }
    int getX() const { return m_x; }
    int getY() const { return m_y; }
    string getColor() const { return m_set->getColor(); }
    int getSize() const { return m_set->getSize(); }
    bool getTracing() const { return m_set->getTracing(); }
    bool getFlicker() const { return m_set->getFlicker(); }

    string toJSON() const {
        stringstream ss;
        ss << "{";
        ss << "\"id\":" << m_id << ",";
        ss << "\"x\":" << m_x << ",";
        ss << "\"y\":" << m_y << ",";
        ss << "\"color\":\"" << m_set->getColor() << "\",";
        ss << "\"size\":" << m_set->getSize() << ",";
        ss << "\"outline\":" << (m_set->getTracing() ? "true" : "false") << ",";
        ss << "\"twinkle\":" << (m_set->getFlicker() ? "true" : "false") << ",";
        ss << "\"b\":" << (rand() % 9 + 1);
        ss << "}";
        return ss.str();
    }
};

StarFactory Star::s_factory;

// КЛАСС НЕБА 
class Sky {
private:
    int m_width;
    int m_height;
    vector<Star> m_stars;
    int m_nextId;
    mutable mutex m_mutex;

public:
    Sky(int width, int height) : m_width(width), m_height(height), m_nextId(1) {}

    int getWidth() const { return m_width; }
    int getHeight() const { return m_height; }

    bool addStar(int x, int y, const string& color, int size, bool tracing, bool flicker) {
        lock_guard<mutex> lock(m_mutex);
        for (const auto& star : m_stars) {
            if (star.getX() == x && star.getY() == y)
                return false;
        }
        if (x < 0 || x >= m_width || y < 0 || y >= m_height)
            return false;
        int id = m_nextId++;
        m_stars.emplace_back(id, x, y, color, size, tracing, flicker);
        return true;
    }

    bool removeStarAt(int x, int y) {
        lock_guard<mutex> lock(m_mutex);
        for (auto it = m_stars.begin(); it != m_stars.end(); ++it) {
            if (it->getX() == x && it->getY() == y) {
                m_stars.erase(it);
                return true;
            }
        }
        return false;
    }

    void clear() {
        lock_guard<mutex> lock(m_mutex);
        m_stars.clear();
        m_nextId = 1;
    }

    size_t count() const {
        lock_guard<mutex> lock(m_mutex);
        return m_stars.size();
    }

    void random(int count) {
        lock_guard<mutex> lock(m_mutex);
        for (int i = 0; i < count; ++i) {
            int x = rand() % m_width;
            int y = rand() % m_height;
            string color = (rand() % 2 == 0) ? "white" : "yellow";
            int size = rand() % 3 + 1;
            bool tracing = rand() % 2;
            bool flicker = rand() % 2;
            bool occupied = false;
            for (const auto& star : m_stars) {
                if (star.getX() == x && star.getY() == y) {
                    occupied = true;
                    break;
                }
            }
            if (!occupied) {
                int id = m_nextId++;
                m_stars.emplace_back(id, x, y, color, size, tracing, flicker);
            }
        }
    }

    string draw() const {
        lock_guard<mutex> lock(m_mutex);
        stringstream ss;
        ss << "[";
        bool first = true;
        for (const auto& star : m_stars) {
            if (!first) ss << ",";
            ss << star.toJSON();
            first = false;
        }
        ss << "]";
        return ss.str();
    }
};

// ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ 
Sky* g_sky = nullptr;
mutex g_skyMutex;

string loadHTMLFile() {
    ifstream file("index.html");
    if (!file.is_open()) {
        return "<html><body><h1>Ошибка: файл index.html не найден</h1></body></html>";
    }
    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    g_sky = new Sky(25, 15);

    httplib::Server svr;

    svr.Get("/", [](const httplib::Request&, httplib::Response& res) {
        string html = loadHTMLFile();
        res.set_content(html, "text/html");
    });

    svr.Get("/api/stars", [](const httplib::Request&, httplib::Response& res) {
        lock_guard<mutex> lock(g_skyMutex);
        string json = "{";
        json += "\"width\":" + to_string(g_sky->getWidth()) + ",";
        json += "\"height\":" + to_string(g_sky->getHeight()) + ",";
        json += "\"count\":" + to_string(g_sky->count()) + ",";
        json += "\"stars\":" + g_sky->draw();
        json += "}";
        res.set_content(json, "application/json");
    });

    svr.Post("/api/star", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(g_skyMutex);
        int x = stoi(req.get_param_value("x"));
        int y = stoi(req.get_param_value("y"));
        int size = stoi(req.get_param_value("size"));
        string color = req.get_param_value("color");
        bool outline = req.get_param_value("outline") == "true";
        bool twinkle = req.get_param_value("twinkle") == "true";

        bool ok = g_sky->addStar(x, y, color, size, outline, twinkle);
        if (ok) {
            res.set_content("{\"status\":\"ok\"}", "application/json");
        } else {
            res.set_content("{\"status\":\"error\",\"message\":\"cell occupied or invalid\"}", "application/json");
        }
    });

    svr.Delete("/api/star", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(g_skyMutex);
        int x = stoi(req.get_param_value("x"));
        int y = stoi(req.get_param_value("y"));
        bool ok = g_sky->removeStarAt(x, y);
        if (ok) {
            res.set_content("{\"status\":\"ok\"}", "application/json");
        } else {
            res.set_content("{\"status\":\"error\",\"message\":\"star not found\"}", "application/json");
        }
    });

    svr.Delete("/api/stars", [](const httplib::Request&, httplib::Response& res) {
        lock_guard<mutex> lock(g_skyMutex);
        g_sky->clear();
        res.set_content("{\"status\":\"ok\"}", "application/json");
    });

    svr.Post("/api/constellation", [](const httplib::Request& req, httplib::Response& res) {
        lock_guard<mutex> lock(g_skyMutex);
        int count = 5;
        if (req.has_param("count")) count = stoi(req.get_param_value("count"));
        g_sky->random(count);
        res.set_content("{\"status\":\"ok\"}", "application/json");
    });

    svr.Get("/api/update", [](const httplib::Request&, httplib::Response& res) {
        res.set_content("{\"status\":\"ok\"}", "application/json");
    });

    svr.listen("0.0.0.0", 8081);

    delete g_sky;
    return 0;
}